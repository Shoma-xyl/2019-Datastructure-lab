#include<iostream>
#include<algorithm>
#define max 50
using namespace std;

typedef struct arcnode
{
	int adjvex;
	struct arcnode *nextarc;
}arcnode;
typedef struct vnode
{
	int data;
	arcnode *firstarc;
}vnode,adjlist[max];
typedef struct
{
	adjlist vertices;
	int vexnum,arcnum;
}Algraph;//����ͼ

int num;
int low[max],visited[max],node[max];

bool sp(int n)
{
	int i;
	for(i=1;i<=node[0];i++)
	{
		if(node[i]==n)
		{
			return false;
		}
	}
	node[0]++;
	node[node[0]]=n;
	return true;
}

void DFSarticul(Algraph *g,int v)
{
	int min,w;
	arcnode *p;
	visited[v]=min=++num;
	for(p=g->vertices[v].firstarc;p;p=p->nextarc)
	{
		w=p->adjvex;
		if(visited[w]==0)
		{
			DFSarticul(g,w);
			if(low[w]<min)
			{
				min=low[w];
			}
			if(low[w]>=visited[v])
			{
				sp(v);
			}
		}
		else if(visited[w]<min)
		{
			min=visited[w];
		}
	}
	low[v]=min;
}

void findarticul(Algraph *g)
{
	int i,v;
	arcnode *p;
	num=1;
	visited[1]=1;
	for(i=2;i<=g->vexnum;i++)
		visited[i]=0;
	p=g->vertices[1].firstarc;
	v=p->adjvex;
	DFSarticul(g,v);
	if(num<g->vexnum)
	{
		sp(1);
		while(p->nextarc)
		{
			p=p->nextarc;
			v=p->adjvex;
			if(visited[v]==0)
			{
				DFSarticul(g,v);
			}
		}
	}
} 

void print(Algraph *g)
{
	int i;
	for(i=1;i<=node[0];i++)
	{
		cout<<g->vertices[node[i]].data;
	}
}

int main()
{
	Algraph *g=(Algraph *)malloc(sizeof(Algraph));
	int n,e,x,y,i,j;
	cin>>n;//���������
	cin>>e;//�������
	g->vexnum=n;//��ֵ����� 
	g->arcnum=e;//��ֵ���� 
	for(i=1;i<=n;i++)
	{
		g->vertices[i].data=i;
		g->vertices[i].firstarc=NULL;
	} 
	for(i=1;i<=e;i++)
	{
		cin>>x>>y;//����һ����
		arcnode *p=(arcnode *)malloc(sizeof(arcnode));//�����µı���� 
		p->adjvex=x;
		p->nextarc=NULL;
		if(g->vertices[y].firstarc==NULL)
		{
			g->vertices[y].firstarc=p;	
		} 
		else
		{
			arcnode *q=g->vertices[y].firstarc;
			while(q->nextarc!=NULL)
			{
				q=q->nextarc;	
			}
			q->nextarc=p;
		}
		arcnode *r=(arcnode *)malloc(sizeof(arcnode));//�����µı���� 
		r->adjvex=y;
		r->nextarc=NULL;
		if(g->vertices[x].firstarc==NULL)
		{
			g->vertices[x].firstarc=r;	
		} 
		else
		{
			arcnode *t=g->vertices[x].firstarc;
			while(t->nextarc!=NULL)
			{
				t=t->nextarc;	
			}
			t->nextarc=r;
		}
	}
	findarticul(g);
	print(g);
	return 0;
} 
