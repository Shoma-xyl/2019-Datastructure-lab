#include "stdio.h"
#include "stdlib.h"
#include<iostream>
#define OK 1
#define ERROR 0
#define TRUE 1
#define FALSE 0
#define MAXEDgE 20
#define MAXVEX 20
#define INFINITY 65535
using namespace std;
typedef int Status;    /* Status�Ǻ���������,��ֵ�Ǻ������״̬���룬��OK�� */


typedef struct
{
    int vexs[MAXVEX];
    int arc[MAXVEX][MAXVEX];
    int numVertexes, numEdges;
}Mgraph;

typedef int Patharc[MAXVEX];            /* ���ڴ洢���·���±������ */
typedef int ShortPathTable[MAXVEX];        /* ���ڴ洢���������·����Ȩֵ�� */


void CreateMgraph(Mgraph *g)
{
    int i, j;
	int w,v;
	cin>>w>>v;
    /* printf("����������Ͷ�����:"); */
    g->numEdges=w;
    g->numVertexes=v;

    for (i = 0; i < g->numVertexes; i++)/* ��ʼ��ͼ */
    {
        g->vexs[i]=i;
    }

    for (i = 0; i < g->numVertexes; i++)/* ��ʼ��ͼ */
    {
        for ( j = 0; j < g->numVertexes; j++)
        {
            if (i==j)
                g->arc[i][j]=0;
            else
                g->arc[i][j] = g->arc[j][i] = INFINITY;
        }
    }
	 for (i = 0; i < g->numVertexes; i++)/* ��ʼ��ͼ */
    {
        for ( j = 0; j < g->numVertexes; j++)
        {
            cin>>g->arc[i][j];
        }
    }
    for(i = 0; i < g->numVertexes; i++)
    {
        for(j = i; j < g->numVertexes; j++)
        {
            g->arc[j][i] =g->arc[i][j];
        }
    }

}

void ShortestPath_Dijkstra(Mgraph g, int v0, Patharc *P, ShortPathTable *D)
{
    int v,w,k,min;
    int final[MAXVEX];                   
    for(v=0; v<g.numVertexes; v++)        
    {
        final[v] = 0;                  
        (*D)[v] = g.arc[v0][v];            
        (*P)[v] = 0;                    
    }

    (*D)[v0] = 0;                        
    final[v0] = 1;                       
    
    for(v=1; v<g.numVertexes; v++)
    {
        min=INFINITY;                   
        for(w=0; w<g.numVertexes; w++) 
        {
            if(!final[w] && (*D)[w]<min)
            {
                k=w;
                min = (*D)[w];           
            }
        }
        final[k] = 1;                    
        for(w=0; w<g.numVertexes; w++)
        {
            if(!final[w] && (min+g.arc[k][w]<(*D)[w]))
            {
                (*D)[w] = min + g.arc[k][w]; 
                (*P)[w]=k;
            }
        }
    }
}

int main(void)
{
    int i,j,v0;
    Mgraph g;
    Patharc P;
    ShortPathTable D; 
    v0=0;
    CreateMgraph(&g);
    ShortestPath_Dijkstra(g, v0, &P, &D);
    printf("\nԴ�㵽����������·������Ϊ:\n");
    for(i=1;i<g.numVertexes;++i)
        printf("v%d - v%d : %d \n",g.vexs[0],g.vexs[i],D[i]);
    return 0;
}
