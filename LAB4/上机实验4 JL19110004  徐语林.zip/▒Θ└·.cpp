#include<iostream>
#include<algorithm>
#include<stack>
#include<queue>
#include<vector>
#define maxsize 200
using namespace std;

typedef struct 
{
	int book[maxsize];
	int edge[maxsize][maxsize];
	int n,e;
}graph;


void creatgraph(graph &g,int w,int v)
{
	int i,j;
	for(i=0;i<w;i++)
	{
		for(j=0;j<w;j++)
		{
			cin>>g.edge[i][j];
		}
	}
	g.n=w;
	g.e=v;
	for(i=0;i<g.n;i++)
	{
		g.book[i]=0;
	}
}

void DFS(graph g,int x)
{
	stack<int>s;
	cout<<x;
	g.book[x]=1;
	s.push(x);
	while(!s.empty())
	{
		int data;
		int i;
		data=s.top();
		for(i=0;i<g.n;i++)
		{
			if(g.edge[data][i]!=0 && g.book[i]!=1)
			{
				cout<<i;
				g.book[i]=1;
				s.push(i);
				break;
			}
		}
		if(i==g.n)
		{
			s.pop();
		}
	}
}

void BFS(graph g,int x)
{
	queue<int>queue;
	cout<<x;
	g.book[x]=1;
	queue.push(x);
		while(!queue.empty())
		{
			int u=queue.front();
			queue.pop();
			for(int j=0;j<g.n;j++)
			{
				if(g.edge[u][j]==1 && g.book[j]==0)
				{
					g.book[j]=1;
					cout<<j;
					queue.push(j);
				}
			}
		}	
}

int main()
{
	graph g;
	int w,v;//WΪ��������vΪ���� 
	cout<<"�����붥�����ͱ�����";
	cin>>w>>v;
	creatgraph(g,w,v);
	DFS(g,0);
	cout<<endl;
	BFS(g,0);
	return 0;
}
