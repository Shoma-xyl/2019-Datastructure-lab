#include<iostream>
#include<stdlib.h>
#include<string.h>
#define maxsize 100
using namespace std;

struct tree
{
	char a;
	struct tree *l;
	struct tree *r;
};

tree *build(char zhong[],char xian[],int n)
{
	if(n<=0)
	{
		return NULL;
	}
	tree *b;
	int k;
	char *p;
	b=(tree *)malloc(sizeof(tree));
	b->a=*xian;
	for(p=zhong;p<zhong+n;p++)
	{
		if(*p==*xian)
		{
			break;
		}
	}
	k=p-zhong;
	b->l=build(zhong,xian+1,k);
	b->r=build(p+1,xian+k+1,n-k-1);
	return b;
}

void disp1(tree *l)
{
	if(l)
	{
		disp1(l->l);
		cout<<l->a;
		disp1(l->r);
	}
}

void disp2(tree *l)
{
	if(l)
	{
		cout<<l->a;
		disp2(l->l);
		disp2(l->r);
	}
}

int main()
{
	int n;
	char zhong[maxsize],xian[maxsize];
	tree *l;
	cin>>zhong;
	cin>>xian;
	n=strlen(zhong);
	l=build(zhong,xian,n);
	disp1(l);
	cout<<endl;
	disp2(l);
	return 0;
}

