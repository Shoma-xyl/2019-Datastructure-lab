#include<stdio.h>
#include<iostream> 
#include<algorithm>
using namespace std;

typedef enum pointertag {link,thread};//link��ʾָ����thread��ʾ������ 
struct node
{
	char data;
	pointertag ltag,rtag;//��־��
	struct node *lchild;
	struct node *rchild; 
};
typedef struct node *Btree;
Btree pre=(node *)malloc(sizeof(node));//ָ��ǰ����� 

void creattree(Btree &a)
{
	char ch;
	cin>>ch;
	if(ch=='#')
	{
		a=NULL;
		return ;
	}
	else
	{
		a=(Btree)malloc(sizeof(node));
		if(!a)
		{
			exit(1);
		}
		a->data=ch;
		a->ltag=link;
		a->rtag=link;
		creattree(a->lchild);
		creattree(a->rchild); 
	}
}

void postthreading(Btree a)
{
	if(a)
	{
		if(a->ltag==link)
		{
			postthreading(a->lchild);	
		}	
		if(a->rtag==link)
		{
			postthreading(a->rchild);
		}
		if(!a->lchild)
		{
			a->ltag=thread;
			a->lchild=pre;
		}
		else
		{
			a->ltag=link;
		}
		if(!pre->rchild)
		{
			pre->rtag=thread;
			pre->rchild=a;
		}
		else
		{
			a->rtag=link;
		}
		pre=a;//����preָ��a��ǰ�� 
	}	
}

void postorderthreading(Btree &s,Btree &a)
{
	s=(node *)malloc(sizeof(Btree));
	s->ltag=link;
	s->rtag=thread;
	s->rchild=s;
	if(a==NULL)
	{
		s->lchild=s;
	}
	else
	{
		s->lchild=a;
		pre=s;
		postthreading(a);
		s->rchild=pre;
	}
}

Btree parent(Btree &s,Btree &p)
{
	Btree t;
	t=s;
	if(t->lchild==p)
	{
		return t;	
	}	
	else
	{
		t=t->lchild;
		while(t->lchild!=p&&t->rchild!=p)
		{
			if(t->rtag==link)
			{
				t=t->rchild;
			}
			else
			{
				t=t->lchild;
			}
		}
		return t;
	}
}

Btree next(Btree s,Btree p)
{
	Btree x;
	x=parent(s,p);
	if(s==x)
	{
		return s;	
	}			
	else if(p==x->rchild||x->rtag==thread)
	{
		return x;
	}
	else 
	{
		while(x->rtag==link)
		{
			x=x->rchild;
			while(x->ltag==link)
			{
				x=x->lchild;	
			}	
		}	
		return x;
	}
}

void traverse(Btree s)
{
	Btree p=s->lchild;
	while(1)
	{
		while(p->ltag==link)
		{
			p=p->lchild;	
		}	
		if(p->rtag==link)
		{
			p=p->rchild;
		}
		else
		{
			break;
		}
	}	
	while(p!=s)
	{
		cout<<p->data;
		p=next(s,p);
	}
} 

int main()
{
	Btree a,s;//preָ��ǰ��,s��ʾͷ��� 
	pre->rtag=thread;
	pre->rchild=NULL;
	creattree(a);
	postorderthreading(s,a);//����������
	traverse(s); 
	return 0; 
}
