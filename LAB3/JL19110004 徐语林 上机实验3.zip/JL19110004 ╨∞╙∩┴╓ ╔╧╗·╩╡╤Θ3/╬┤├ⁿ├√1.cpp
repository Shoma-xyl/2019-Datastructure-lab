#include<iostream>
#include<stdio.h>  
#include<stdlib.h>  
#include<string.h>
#define maxsize 100  
using namespace std;
 
typedef struct node  
{      
    char data;    
    struct node *lchild;  
    struct node *rchild;  
}TreeNode;  
   
typedef struct Tree_Stack  
{  
    TreeNode *b[maxsize];  
    int n;  
}TreeStack;  
  
typedef struct Stack
{
	int v[maxsize];
	int top;
}stack;
 
TreeStack *create(TreeStack *pstack)  
{  
    pstack=(TreeStack *)malloc(sizeof(TreeStack));  
    pstack->n=-1;  
    return pstack;  
}  
   
bool push_stack(TreeStack *p, TreeNode *e)  
{  
    p->n++;  
    p->b[p->n]=e;  
    return true;  
}  
   
TreeNode *pop_stack(TreeStack *p)  
{  
    TreeNode *e;  
	e=p->b[p->n];  
    p->n--;  
    return e;  
}  
   
bool is_empty_stack(TreeStack *p)  
{  
    if(p->n==-1)  
        return true;  
    else  
        return false;  
}  
  
TreeNode *createtree(char *str, TreeStack *p)  
{  
    int i=0;  
    TreeNode *t;  
    TreeNode *left, *right;  
    while(str[i])  
    {  
        if(str[i]>='0'&&str[i]<='9')  
        {  
            t=(TreeNode *)malloc(sizeof(TreeNode));  
            t->data=str[i];  
            t->lchild=NULL;  
            t->rchild=NULL;  
            push_stack(p,t);  
        }  
        else  
        {  
            t= (TreeNode *)malloc(sizeof(TreeNode));  
            t->data=str[i];  
            right=pop_stack(p);  
            left=pop_stack(p);  
            t->lchild=left;  
            t->rchild=right;  
            push_stack(p,t);  
        }  
        i++;  
    }  
    return p->b[p->n];  
}  
  
void PostOrder(TreeNode *p)  
{  
    if(p)  
    {  
        PostOrder(p->lchild);  
        PostOrder(p->rchild);  
        cout<<p->data; 
    }  
}  
   
void InOrder(TreeNode *p)  
{  
    if(p)  
    {  
        InOrder(p->lchild);  
        cout<<p->data;
        InOrder(p->rchild);  
    }  
}  
    
void PreOrder(TreeNode *p)  
{  
    if(p)  
    {  
        cout<<p->data;  
        PreOrder(p->lchild);  
        PreOrder(p->rchild);  
    }  
}  
 
void init(stack *&s)
{
	s=(stack *)malloc(sizeof(stack));
	s->top=-1;	
}

bool push(stack *&s,char e)
{
	if(s->top==maxsize)
	{
		return false;
	}
	s->v[++s->top]=e;
	return true;
}

bool pop1(stack *&s)
{
	if(s->top==-1)
	{
		return false;
	}
	s->top--;
	return true;
}
 
int main()  
{  
    TreeNode *l;  
    TreeStack *p; 
	stack *y;
	init(y);
    int i=0;
	int len,j,n,m;  
    char x[maxsize];  
    cin>>x; 
	len=strlen(x); 
    p=create(p);  
    l=createtree(x, p);  
    PostOrder(l);  
    cout<<endl;
    InOrder(l);  
    cout<<endl;  
    PreOrder(l);  
    cout<<endl;
	for(j=0;j<len;j++)
	{
		if(x[j]>='0'&&x[j]<='9')
		{
			push(y,x[j]-'0');
		}
		else if(x[j]=='+'||x[j]=='-'||x[j]=='*'||x[j]=='/')
		{
			m=y->v[y->top];
			pop1(y);
			n=y->v[y->top];
			pop1(y);
			if(x[j]=='+')
			{
				push(y,m+n);
			}
			else if(x[j]=='-')
			{
				push(y,n-m);	
			} 
			else  if(x[j]=='*')
			{
				push(y,n*m);
			}
			else  if(x[j]=='/')
			{
				if(m==0)
				{
					return -1;
				}
				push(y,n/m);
			}
		}
	}
	if(y->top==0)
	{
		cout<<y->v[y->top]<<endl;
	}
    return 0;  
}  
